﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MyJson
{
    internal class Program
    {
        public class ResidentialAddress
        {
            public string BlockStreetNo { get; set; }
            public string StreetName { get; set; }
            public string UnitNo { get; set; }
            public string BuildingName { get; set; }
            public string PostalCode { get; set; }
            public string Country { get; set; }
            public string AddressType { get; set; }
            public string ResidencyStatus { get; set; }
            public string EmailAddress { get; set; }
        }

        public class CustomerDetail
        {
            public string CustId { get; set; }
            public string Salutation { get; set; }
            public string Surname { get; set; }
            public string GivenName { get; set; }
            public ResidentialAddress ResidentialAddress { get; set; }
        }

        public class Root
        {
            public string Version { get; set; }
            public string Company { get; set; }
            public string CreatedDate { get; set; }
            public List<CustomerDetail> CustomerDetails { get; set; }
        }

        static void Main(string[] args)
        {
            var customerDetails = new List<CustomerDetail>
            {
                new CustomerDetail
                {
                    CustId = "00000001",
                    Salutation = "MR",
                    Surname = "Lim",
                    GivenName = "Kai Zhuo Nigel",
                    ResidentialAddress = new ResidentialAddress
                    {
                        BlockStreetNo = "59",
                        StreetName = "Lorong H Telok Kurau",
                        UnitNo = "03-01",
                        BuildingName = "First Point Suites",
                        PostalCode = "123456",
                        Country = "SG",
                        AddressType = "R",
                        ResidencyStatus = "",
                        EmailAddress = "mikilee24@gmail.com"
                    }
                },
                new CustomerDetail
                {
                    CustId = "00000002",
                    Salutation = "MRS",
                    Surname = "Lim",
                    GivenName = "Agnel",
                    ResidentialAddress = new ResidentialAddress
                    {
                        BlockStreetNo = "59",
                        StreetName = "Lorong H Telok Kurau",
                        UnitNo = "03-01",
                        BuildingName = "First Point Suites",
                        PostalCode = "123456",
                        Country = "SG",
                        AddressType = "R",
                        ResidencyStatus = "",
                        EmailAddress = "mikilee24@gmail.com"
                    }
                },
                new CustomerDetail
                {
                    CustId = "",
                    Salutation = "",
                    Surname = "",
                    GivenName = "",
                    ResidentialAddress = new ResidentialAddress
                    {
                        BlockStreetNo = "",
                        StreetName = "",
                        BuildingName = "",
                        PostalCode = "",
                        Country = "",
                        AddressType = "",
                        ResidencyStatus = "",
                        EmailAddress = ""
                    }
                }
            };

            var root = new Root
            {
                Version = "2.2",
                Company = "Trusted Hub",
                CreatedDate = "20121214",
                CustomerDetails = customerDetails
            };

            var options = new JsonSerializerOptions { WriteIndented = true };
            string jsonString = JsonSerializer.Serialize(root, options);

            // Ensure the myOutput folder exists
            string folderPath = Path.Combine(Directory.GetCurrentDirectory(), "myOutput");
            Directory.CreateDirectory(folderPath);

            // Write the JSON file to the myOutput folder
            string filePath = Path.Combine(folderPath, "output.json");
            File.WriteAllText(filePath, jsonString);

            Console.WriteLine("JSON file has been generated successfully at : " + folderPath);
        }
    }
}
