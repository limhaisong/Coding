﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsertNewTable
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string connectionString = "Server=DESKTOP-R5R9R8A\\SQLEXPRESS;Database=Table_Employee;Trusted_Connection=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Check if TEST table exists
                string checkTableQuery = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'TEST';";
                bool tableExists = false;

                using (SqlCommand checkCmd = new SqlCommand(checkTableQuery, connection))
                {
                    int count = (int)checkCmd.ExecuteScalar();
                    tableExists = count > 0;
                }

                if (!tableExists)
                {
                    // Create the table
                    string createTableQuery = @"
                        CREATE TABLE TEST (
                            TEST_ID INT IDENTITY(1,1) PRIMARY KEY,
                            TEST_VALUE1 INT,
                            TEST_VALUE2 INT
                        );";

                    using (SqlCommand cmd = new SqlCommand(createTableQuery, connection))
                    {
                        cmd.ExecuteNonQuery();
                        Console.WriteLine("Table 'TEST' created successfully.");
                    }

                    // Insert 100 rows
                    for (int i = 1; i <= 100; i++)
                    {
                        string insertQuery = "INSERT INTO TEST (TEST_VALUE1, TEST_VALUE2) VALUES (@value1, @value2);";
                        using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                        {
                            cmd.Parameters.AddWithValue("@value1", i);
                            cmd.Parameters.AddWithValue("@value2", 100 + i - 1);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    Console.WriteLine("100 rows inserted into 'TEST' successfully.");
                }
                else
                {
                    Console.WriteLine("Table 'TEST' already exists. No new rows were added.");
                }
            }

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
