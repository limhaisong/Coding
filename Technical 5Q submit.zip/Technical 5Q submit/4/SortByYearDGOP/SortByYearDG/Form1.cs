﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SortByYearDG
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Server=DESKTOP-R5R9R8A\\SQLEXPRESS;Database=Table_Employee;Trusted_Connection=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Step 1: Get distinct Year_of_Experience values
                List<int> yearsOfExperience = new List<int>();
                using (SqlCommand cmd = new SqlCommand("SELECT DISTINCT Year_of_Experience FROM Employee WHERE Year_of_Experience IS NOT NULL ORDER BY Year_of_Experience", connection))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        yearsOfExperience.Add(reader.GetInt32(0));
                    }
                }

                // Step 2: Build dynamic SQL query
                string dynamicColumns = string.Join(", ", yearsOfExperience.Select(year =>
                    $"MAX(CASE WHEN Year_of_Experience = {year} THEN EmployeeName ELSE NULL END) AS [Year_of_Experience_{year}]"
                ));

                string query = $@"
                    WITH RankedEmployees AS (
                        SELECT 
                            EmployeeName,
                            Year_of_Experience,
                            ROW_NUMBER() OVER (PARTITION BY Year_of_Experience ORDER BY ID ASC) AS RowNum
                        FROM Employee
                        WHERE Year_of_Experience IS NOT NULL
                    )
                    SELECT {dynamicColumns}
                    FROM RankedEmployees
                    GROUP BY RowNum
                    ORDER BY RowNum;";

                // Step 3: Execute the dynamic query
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                DataTable resultTable = new DataTable();
                dataAdapter.Fill(resultTable);

                // Replace NULLs with 'Null' in the DataGridView
                foreach (DataRow row in resultTable.Rows)
                {
                    for (int i = 0; i < resultTable.Columns.Count; i++)
                    {
                        if (row.IsNull(i))
                        {
                            row[i] = "Null";
                        }
                    }
                }

                dataGridView1.DataSource = resultTable;

                // Auto resize columns based on header text
                dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.ColumnHeader);
            }

        }
    }
}
