﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GetEmployeeName
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "Server=DESKTOP-R5R9R8A\\SQLEXPRESS;Database=Table_Employee;Trusted_Connection=True;";

            if (!int.TryParse(textBox1.Text, out _))
            {
                MessageBox.Show("Error: Please enter a valid number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string query = $"SELECT EmployeeName FROM Employee where id={int.Parse(textBox1.Text)}";
                textBox3.Text = "";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);
                    if(dataTable.Rows.Count==0)
                    {
                        MessageBox.Show("Error: Could not find this employee.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        foreach (DataRow row in dataTable.Rows)
                        {
                            foreach (DataColumn column in dataTable.Columns)
                            {
                                textBox3.Text = ($"{row[column]}{Environment.NewLine}");
                            }
                        }
                    }
                }
            }
            
        }
    }
}
